package org.poo.commands;

/**
 * The interface Command.
 */
public interface Command {
    /**
     * Execute.
     */
    void execute();
}
